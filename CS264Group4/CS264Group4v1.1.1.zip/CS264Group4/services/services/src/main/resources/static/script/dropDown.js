function toggleDropdown() {
        var dropdown = document.querySelector('.dropdown');
        dropdown.classList.toggle('active');
    }