function goToTeacherHomepage(){
    window.location = "mainAjarn.html"
}

function goToEmployeeHomepage(){
    window.location = "employeeHomepage.html"
}

function goToStudentPetition(){
     window.location = "studentPetition.html"
}
function goToQuitPetition(){
     window.location = "quitPetition.html"
}
function goToTuitionPetition(){
     window.location = "tuitionPetition.html"
}
function goToOtherPetition(){
     window.location = "otherPetition.html"
}
function goToConditionStudent(){
    window.location = "conditionStudent.html"
}

function goToAjarn_Student(){
    window.location = "Ajarn_Student.html"
}